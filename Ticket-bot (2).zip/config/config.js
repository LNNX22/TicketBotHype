module.exports = {
  clientId: "1291893187010629692", // The id of the discord bot
  guildId: "1206414367189504070", // The id of the discord server
  mainColor: "#EB06D4", // The hex color of the embeds by default
  lang: "main", // If you want to set english please set "main"


  openTicketChannelId: "1207108956644835408", // The id of the channel where the message to create a ticket will be sent
  ticketTypes: [ // You have a limit of 25 types (the limit of Discord)
    {
      codeName: "discord-support", // The name need to be in lowercase
      name: "Discord Support", // The name that will be displayed in the ticket
      emoji: "", // The emoji of the type (can be blank)
      color: "", // Can be a hex color or blank to use the main color
      categoryId: "1207105892663693313", // The category id where the tickets will be created
      customDescription: "Please explain your question in detail. If you have any images, please attach them to your message.\n\nReason: REASON", // The custom description of the ticket type (set to blank to use the default description)
      askReason: true // If the bot should ask the reason of the ticket
    },
    {
      codeName: "server-support", // The name need to be in lowercase
      name: "Server Support", // The name that will be displayed in the ticket
      emoji: "", // The emoji of the type (can be blank)
      color: "", // Can be a hex color or blank to use the main color
      categoryId: "1207105892663693313", // The category id where the tickets will be created
      customDescription: "", // The custom description of the ticket type (set to blank to use the default description)
      askReason: true // If the bot should ask the reason of the ticket
    },
    {
      codeName: "purchase-redemption", // The name need to be in lowercase
      name: "Purchase Redemption", // The name that will be displayed in the ticket
      emoji: "", // The emoji of the type (can be blank)
      color: "", // Can be a hex color or blank to use the main color
      categoryId: "1207105892663693313", // The category id where the tickets will be created
      customDescription: "", // The custom description of the ticket type (set to blank to use the default description)
      askReason: true // If the bot should ask the reason of the ticket
    },
    {
      codeName: "player-report", // The name need to be in lowercase
      name: "Player Report", // The name that will be displayed in the ticket
      emoji: "", // The emoji of the type (can be blank)
      color: "#f8312f", // Can be a hex color or blank to use the main color
      categoryId: "1207105892663693313", // The category id where the tickets will be created
      customDescription: "Please explain your report in detail. If you have any images, please attach them to your message.\n\nReason: REASON", // The custom description of the ticket type (set to blank to use the default description)
      askReason: true // If the bot should ask the reason of the ticket
    },
    {
      codeName: "bug-report", // The name need to be in lowercase
      name: "Bug Report", // The name that will be displayed in the ticket
      emoji: "", // The emoji of the type (can be blank)
      color: "#f8312f", // Can be a hex color or blank to use the main color
      categoryId: "1207105892663693313", // The category id where the tickets will be created
      customDescription: "Please explain your report in detail. If you have any images, please attach them to your message.\n\nReason: REASON", // The custom description of the ticket type (set to blank to use the default description)
      askReason: true // If the bot should ask the reason of the ticket
    },
    {
      codeName: "other", // The name need to be in lowercase
      name: "Other", // The name that will be displayed in the ticket
      emoji: "", // The emoji of the type (can be blank)
      color: "", // Can be a hex color or blank to use the main color
      categoryId: "1207105892663693313", // The category id where the tickets will be created
      customDescription: "", // The custom description of the ticket type (set to blank to use the default description)
      askReason: true // If the bot should ask the reason of the ticket
    }
  ],
  ticketNameOption: "Ticket-TICKETCOUNT", // Here is all parameter: USERNAME, USERID, TICKETCOUNT
  rolesWhoHaveAccessToTheTickets: [
    "1258146537280901181",
  ], // Roles who can access to the tickets
  pingRoleWhenOpened: true,
  roleToPingWhenOpenedId: "1213357069042978836", // The role to ping when a ticket is opened
  logs: true,
  logsChannelId: "1207108956644835408", // The id of the channel where the logs will be sent
  claimButton: true,
  whoCanCloseTicket: "STAFFONLY", // STAFFONLY (roles configured at "rolesWhoHaveAccessToTheTickets") or EVERYONE
  closeButton: true, // If false the ticket can be closed only by doing /closes
  askReasonWhenClosing: true, // If false the ticket will be closed without asking the reason
  maxTicketOpened: 2 // The number of tickets the user can open while another one is already open. Set to 0 to unlimited
}
